#Initialize the Variables
score = None
max_score = None
list_capacity = None
max_lc = None
l = None
flag = None
apple_x = None
apple_y = None
center = None
radius = None
circle_colour = None
prev_c = None
frame_copy = None
img = None
co_ord = None
red_circle_center = None
frame = None
color_lower_limit = None
color_upper_limit = None
mask = None
cnts = None
M = None
apple = None
k = None

#Import libraries 
import cv2
import imutils
from collections import deque
import numpy as np
np.set_printoptions(suppress=True) # prevent numpy exponential
import time
score = 0
max_score = 5
list_capacity = 0
max_lc = 20
l = []
flag = 0
apple_x = None
apple_y = None
center = None
radius = None
circle_colour = (0, 0, 255)
prev_c = None
frame_copy = None

#distance function:calculate the Euclidean distance between two points
def dist(pt1,pt2):
	if pt1 is None or pt2 is None:
		return 0
	return np.sqrt((pt1[0]-pt2[0])**2 + (pt1[1]-pt2[1])**2)

#Create a video capture object
cap = cv2.VideoCapture(0)

#Snake game
while True:
  #Read a frame from the video capture
  ret, frame = cap.read()
  frame_copy = frame.copy()
  #Preprocess the frame
  img = imutils.resize(frame_copy, width = 600)
  img = cv2.GaussianBlur(img, (11, 11), 0)
  img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
  #Check if the coordinates of the apple are not assigned
  if apple_x == None and apple_y == None:
    co_ord = frame.shape[0]-30
    # assigning random coefficients for apple coordinates
    apple_x = np.random.randint(30, co_ord)
    apple_y = np.random.randint(100, 350)
  
  #Draw a red circle at the apple's coordinates     
  red_circle_center = (apple_x, apple_y)
  cv2.circle(frame, red_circle_center, 3, circle_colour, -1)
  
  #Define the lower and upper color limits for masking the snake
  color_lower_limit = (29, 86, 18)
  color_upper_limit = (93, 255, 255)
  
  #Masking out the green color  
  mask = cv2.inRange(img,color_lower_limit,color_upper_limit)
  mask = cv2.erode(mask,None, iterations = 2)
  mask = cv2.dilate(mask,None, iterations = 2)

  #Find the contours in the masked image
  cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
  cnts = imutils.grab_contours(cnts)

  #Process the contours if any are found
  if len(cnts) > 0:
    ball_cont = max(cnts,key=cv2.contourArea)
    (x,y),radius = cv2.minEnclosingCircle(ball_cont)
    M = cv2.moments(ball_cont)

    center = (int(M['m10']/M['m00']),int(M['m01']/M['m00']))

    if radius > 10:
      cv2.circle(frame, center, 2, circle_colour, 3)
      if len(l) > list_capacity:
        l = l[1 : ]
      if prev_c and (dist(prev_c, center)) > 3.5:
        l.append(center)
      apple = (apple_x, apple_y)
      if (dist(apple, center)) < 5:
        score = score + 1
        if score == max_score:
          flag = 1
        list_capacity = list_capacity + 1
        apple_x = None
        apple_y = None
  else:
    cv2.putText(frame, 'Show a Green Object', (150, 250), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
  
  #Draw lines to connect the snake's body points
  for i in range(1,len(l)):
    if l[i-1] is None or l[i] is None:
      continue
    r,g,b = np.random.randint(0,255,3)
    cv2.line(frame,l[i],l[i-1],(int(r),int(g),int(b)), thickness = int(len(l)/max_lc+2)+2)
  
  #Display the score on the frame  
  cv2.putText(frame, 'Score :  ' + str(score), (450, 100), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 1)

  #Check if the game has been won
  if flag == 1:
    cv2.putText(frame, 'Game Over !!', (100, 250), cv2.FONT_HERSHEY_COMPLEX, 2, (255, 255, 0), 3)
    cv2.putText(frame, "'ENTER' to Play", (150, 300), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
    cv2.putText(frame, "'Q' or 'ESC' to Exit", (150, 350), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
    cv2.imshow('live feed',frame)
    k = cv2.waitKey(0)

    if k == 13:
      score = 0
      flag = 0
      list_capacity = 0
      max_lc = 20
      l = []
      apple_x = None
      apple_y = None
      center = None
    else:
      break
  
  #Display the processed frame 
  cv2.imshow('live feed',frame)
  prev_c = center

  #Handle keyboard events
  if cv2.waitKey(1) & 0xFF == ord('q'):
  		break

#Clean up resources and exit 
cap.release()
cv2.destroyAllWindows()
